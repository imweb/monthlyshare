var HelloWorld = require('./lm.helloworld.js')['lm']['helloworld'];
var fs = require('fs');

var hw = new HelloWorld({
    'id': 101,
    'str': 'Hello'
})

var buffer = hw.encode();

fs.writeFile('./test.log', buffer.toBuffer(), function(err) {
    if(!err) {
        console.log('done!');
    }
});