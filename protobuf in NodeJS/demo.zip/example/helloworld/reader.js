var HelloWorld = require('./lm.helloworld.js')['lm']['helloworld'];
var fs = require('fs');

var buffer = fs.readFile('./test.log', function(err, data) {
    if(!err) {
        console.log(data); // 来看看Node里的Buffer对象长什么样子。
        var message = HelloWorld.decode(data);
        console.log(message);
    }
})